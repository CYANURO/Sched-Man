The routing used in this sample code requires a Web Server to serve the view templates. So you cannot run this code simply by executing the index.html file.

The *easiest* way to run the code from this point forward is to use an IDE such as WebStorm or Visual Studio.

Alternatively, you can set up a local Web Server.
- You can use something like this: python -mSimpleHTTPServer
OR
- You can set up IIS/IIS Express
Then you can execute this code using http://localHost:xxx/index.html

A third option is to download the required templates on application star-up by inserting script tags in index.html:
<script type="text/ng-template" src="app/welcomeView.html"></script>


